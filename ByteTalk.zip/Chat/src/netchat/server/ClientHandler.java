package netchat.server;

import java.io.*;
import java.net.*;
import java.util.Set;

public class ClientHandler implements Runnable {
    private Socket socket;
    private PrintWriter out;
    private BufferedReader in;
    private DataOutputStream dataOut;
    private DataInputStream dataIn;
    private Set<ClientHandler> clients;

    public ClientHandler(Socket socket, Set<ClientHandler> clients) {
        this.socket = socket;
        this.clients = clients;
    }

    @Override
    public void run() {
        try {
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            out = new PrintWriter(socket.getOutputStream(), true);
            dataOut = new DataOutputStream(socket.getOutputStream());
            dataIn = new DataInputStream(socket.getInputStream());

            while (true) {
                String command = in.readLine();
                if (command == null) break;

                if (command.startsWith("MSG:")) {
                    String msg = command.substring(4);
                    System.out.println("💬 Message: " + msg);
                    broadcast(msg);
                } else if (command.startsWith("FILE:")) {
                    String filename = command.substring(5);
                    int length = dataIn.readInt();
                    byte[] fileData = new byte[length];
                    dataIn.readFully(fileData);
                    System.out.println("📁 Received file: " + filename);
                    broadcastFile(filename, fileData);
                }
            }
        } catch (IOException e) {
            System.out.println("❌ Client disconnected.");
        } finally {
            try { socket.close(); } catch (IOException e) {}
            clients.remove(this);
        }
    }

    private void broadcast(String message) {
        for (ClientHandler client : clients) {
            if (client != this) client.sendMessage(message);
        }
    }

    private void broadcastFile(String filename, byte[] fileData) {
        for (ClientHandler client : clients) {
            if (client != this) client.sendFile(filename, fileData);
        }
    }

    public void sendMessage(String message) {
        out.println(message);
    }

    public void sendFile(String filename, byte[] fileData) {
        try {
            out.println("FILE:" + filename);
            dataOut.writeInt(fileData.length);
            dataOut.write(fileData);
            dataOut.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
