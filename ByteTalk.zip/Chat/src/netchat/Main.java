package netchat;

import netchat.client.ClientWithLoginAndFile;

public class Main {
    public static void main(String[] args) {
        ClientWithLoginAndFile.main(args);
    }
}
