package netchat.client;

import com.formdev.flatlaf.FlatLightLaf;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.io.*;
import java.net.*;

public class ChatWindow extends JFrame {
    private Socket socket;
    private PrintWriter out;
    private BufferedReader in;
    private DataOutputStream dataOut;
    private DataInputStream dataIn;

    private JPanel chatPanel;
    private JScrollPane scrollPane;
    private JTextField textField;
    private String username;

    public ChatWindow(String username) {
        this.username = username;

        // Modern UI Look
        try { UIManager.setLookAndFeel(new FlatLightLaf()); }
        catch (Exception ignored) {}

        setTitle("ByteTalk - Chat (" + username + ")");
        setSize(700, 500);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // ---- Header ----
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(new Color(33, 150, 243));
        header.setBorder(new EmptyBorder(10, 15, 10, 15));

        JLabel title = new JLabel("ByteTalk Messenger");
        title.setFont(new Font("Segoe UI", Font.BOLD, 18));
        title.setForeground(Color.WHITE);

        JLabel userLabel = new JLabel("👤 " + username);
        userLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        userLabel.setForeground(Color.WHITE);

        header.add(title, BorderLayout.WEST);
        header.add(userLabel, BorderLayout.EAST);

        // ---- Chat Panel ----
        chatPanel = new JPanel();
        chatPanel.setLayout(new BoxLayout(chatPanel, BoxLayout.Y_AXIS));
        chatPanel.setBackground(new Color(245, 245, 245));

        scrollPane = new JScrollPane(chatPanel);
        scrollPane.setBorder(null);

        // ---- Input Panel ----
        textField = new JTextField(40);
        textField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        textField.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));

        JButton sendBtn = new JButton("➤ Send");
        sendBtn.setBackground(new Color(33, 150, 243));
        sendBtn.setForeground(Color.white);

        JButton fileBtn = new JButton("📁 File");
        fileBtn.setBackground(new Color(76, 175, 80));
        fileBtn.setForeground(Color.white);

        JPanel inputPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        inputPanel.add(textField);
        inputPanel.add(sendBtn);
        inputPanel.add(fileBtn);

        // Layout
        setLayout(new BorderLayout());
        add(header, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(inputPanel, BorderLayout.SOUTH);

        // Actions
        sendBtn.addActionListener(e -> sendMessage());
        fileBtn.addActionListener(e -> sendFile());
        textField.addActionListener(e -> sendMessage());

        // Connect
        connectToServer();
        new Thread(this::readMessages).start();

        setVisible(true);
    }

    private void connectToServer() {
        try {
            socket = new Socket("127.0.0.1", 12345);
            out = new PrintWriter(socket.getOutputStream(), true);
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            dataOut = new DataOutputStream(socket.getOutputStream());
            dataIn = new DataInputStream(socket.getInputStream());
            addMessage("✅ Connected to server", false);
        } catch (IOException e) {
            addMessage("❌ Could not connect to server", false);
        }
    }

    private void sendMessage() {
        String msg = textField.getText();
        if (!msg.isEmpty()) {
            out.println("MSG:" + username + ": " + msg);
            addMessage("Me: " + msg, true);
            textField.setText("");
        }
    }

    private void sendFile() {
        JFileChooser chooser = new JFileChooser();
        if (chooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            File file = chooser.getSelectedFile();
            try {
                byte[] fileData = java.nio.file.Files.readAllBytes(file.toPath());
                out.println("FILE:" + file.getName());
                dataOut.writeInt(fileData.length);
                dataOut.write(fileData);
                dataOut.flush();
                addMessage("📤 File sent: " + file.getName(), true);
            } catch (IOException e) {
                addMessage("❌ Error sending file", true);
            }
        }
    }

    private void readMessages() {
        try {
            while (true) {
                String command = in.readLine();
                if (command == null) break;

                if (command.startsWith("FILE:")) {
                    String filename = command.substring(5);
                    int length = dataIn.readInt();
                    byte[] fileData = new byte[length];
                    dataIn.readFully(fileData);

                    File received = new File("downloads/" + filename);
                    received.getParentFile().mkdirs();
                    try (FileOutputStream fos = new FileOutputStream(received)) {
                        fos.write(fileData);
                    }
                    addMessage("📥 File received: " + filename + " (saved in downloads)", false);
                } else {
                    addMessage(command, false);
                }
            }
        } catch (IOException e) {
            addMessage("❌ Disconnected from server", false);
        }
    }

    // ---- Custom Message Bubbles ----
    private void addMessage(String message, boolean isMe) {
        JPanel bubble = new JPanel();
        bubble.setLayout(new BorderLayout());
        bubble.setBorder(new EmptyBorder(5, 10, 5, 10));

        JLabel msgLabel = new JLabel("<html><p style='width:200px;'>" + message + "</p></html>");
        msgLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        msgLabel.setOpaque(true);

        if (isMe) {
            msgLabel.setBackground(new Color(33, 150, 243));
            msgLabel.setForeground(Color.white);
            bubble.add(msgLabel, BorderLayout.EAST);
        } else {
            msgLabel.setBackground(new Color(224, 224, 224));
            msgLabel.setForeground(Color.black);
            bubble.add(msgLabel, BorderLayout.WEST);
        }

        chatPanel.add(bubble);
        chatPanel.revalidate();
        chatPanel.repaint();

        SwingUtilities.invokeLater(() ->
                scrollPane.getVerticalScrollBar().setValue(
                        scrollPane.getVerticalScrollBar().getMaximum()
                )
        );
    }
}
