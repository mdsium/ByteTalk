package bytechat.client;

import bytechat.db.DatabaseHelper;
import com.formdev.flatlaf.FlatLightLaf;
import javax.swing.*;
import java.awt.*;

public class LoginForm extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;

    public LoginForm() {
        try { UIManager.setLookAndFeel(new FlatLightLaf()); }
        catch (Exception ignored) {}

        setTitle("ByteTalk - Login/Register");
        setSize(600, 350);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Center on screen

        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Title
        JLabel title = new JLabel("Welcome to ByteTalk", SwingConstants.CENTER);
        title.setFont(new Font("Segoe UI", Font.BOLD, 18));
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        panel.add(title, gbc);

        // Username
        gbc.gridwidth = 1;
        gbc.gridx = 0; gbc.gridy = 1;
        panel.add(new JLabel("Username:"), gbc);

        gbc.gridx = 1;
        usernameField = new JTextField(15);
        panel.add(usernameField, gbc);

        // Password
        gbc.gridx = 0; gbc.gridy = 2;
        panel.add(new JLabel("Password:"), gbc);

        gbc.gridx = 1;
        passwordField = new JPasswordField(15);
        panel.add(passwordField, gbc);

        // Buttons
        JButton loginBtn = new JButton("Login");
        JButton registerBtn = new JButton("Register");

        gbc.gridx = 0; gbc.gridy = 3;
        panel.add(loginBtn, gbc);

        gbc.gridx = 1;
        panel.add(registerBtn, gbc);

        // Button actions
        loginBtn.addActionListener(e -> loginUser());
        registerBtn.addActionListener(e -> registerUser());

        add(panel);
        setVisible(true);
    }

    private void loginUser() {
        String user = usernameField.getText();
        String pass = new String(passwordField.getPassword());

        if (DatabaseHelper.validateLogin(user, pass)) {
            JOptionPane.showMessageDialog(this, "Login successful!");
            new ChatWindow(user);
            dispose();
        } else {
            JOptionPane.showMessageDialog(this, "Invalid credentials!");
        }
    }

    private void registerUser() {
        String user = usernameField.getText();
        String pass = new String(passwordField.getPassword());

        if (DatabaseHelper.registerUser(user, pass)) {
            JOptionPane.showMessageDialog(this, " Registration successful!");
        } else {
            JOptionPane.showMessageDialog(this, "User already exists or error.");
        }
    }
}