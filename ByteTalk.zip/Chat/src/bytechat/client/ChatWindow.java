package bytechat.client;

import com.formdev.flatlaf.FlatLightLaf;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.io.*;
import java.net.*;

public class ChatWindow extends JFrame {
    private Socket socket;
    private DataOutputStream dataOut;
    private DataInputStream dataIn;

    private JPanel chatPanel;
    private JScrollPane scrollPane;
    private JTextField textField;
    private String username;

    private volatile boolean running = true;

    public ChatWindow(String username) {
        this.username = username;

        // Modern Look
        try {
            UIManager.setLookAndFeel(new FlatLightLaf());
        } catch (Exception ignored) {}

        setTitle("ByteTalk - Chat (" + username + ")");
        setSize(700, 500);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // ---- Header ----
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(new Color(33, 150, 243));
        header.setBorder(new EmptyBorder(10, 15, 10, 10));

        JLabel title = new JLabel("ByteTalk");
        title.setFont(new Font("Segoe UI", Font.BOLD, 18));
        title.setForeground(Color.WHITE);

        JLabel userLabel = new JLabel("User: " + username);
        userLabel.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        userLabel.setForeground(Color.WHITE);

        JButton logoutBtn = new JButton("Logout");
        logoutBtn.setBackground(new Color(201, 73, 63));
        logoutBtn.setForeground(Color.WHITE);
        logoutBtn.setFocusPainted(false);
        logoutBtn.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));

        JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        rightPanel.setOpaque(false);
        rightPanel.add(userLabel);
        rightPanel.add(logoutBtn);

        header.add(title, BorderLayout.WEST);
        header.add(rightPanel, BorderLayout.EAST);

        // ---- Chat Panel ----
        chatPanel = new JPanel();
        chatPanel.setLayout(new BoxLayout(chatPanel, BoxLayout.Y_AXIS));
        chatPanel.setBackground(new Color(189, 208, 239));

        scrollPane = new JScrollPane(chatPanel);
        scrollPane.setBorder(null);

        // ---- Input Panel ----
        textField = new JTextField(40);
        textField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        textField.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));

        JButton sendBtn = new JButton("➤ Send");
        sendBtn.setBackground(new Color(33, 150, 243));
        sendBtn.setForeground(Color.white);

        JButton fileBtn = new JButton("📁 File");
        fileBtn.setBackground(new Color(76, 175, 80));
        fileBtn.setForeground(Color.white);

        JPanel inputPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        inputPanel.add(textField);
        inputPanel.add(sendBtn);
        inputPanel.add(fileBtn);

        setLayout(new BorderLayout());
        add(header, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(inputPanel, BorderLayout.SOUTH);

        // ---- Actions ----
        sendBtn.addActionListener(e -> sendMessage());
        fileBtn.addActionListener(e -> sendFile());
        textField.addActionListener(e -> sendMessage());
        logoutBtn.addActionListener(e -> logout());

        // ---- Connect to Server ----
        connectToServer();
        new Thread(this::readMessages).start();

        setVisible(true);
    }

    private void connectToServer() {
        try {
            socket = new Socket("127.0.0.1", 12345);
            dataOut = new DataOutputStream(socket.getOutputStream());
            dataIn = new DataInputStream(socket.getInputStream());
            addMessage(" Connected to server", false);
        } catch (IOException e) {
            addMessage(" Could not connect to server", false);
        }
    }

    private void sendMessage() {
        String msg = textField.getText().trim();
        if (!msg.isEmpty()) {
            try {
                dataOut.writeUTF("MSG:" + username + ": " + msg);
                dataOut.flush();
                addMessage("Me: " + msg, true);
                textField.setText("");
            } catch (IOException e) {
                addMessage(" Error sending message", true);
            }
        }
    }

    private void sendFile() {
        JFileChooser chooser = new JFileChooser();
        if (chooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            File file = chooser.getSelectedFile();
            try {
                byte[] fileData = java.nio.file.Files.readAllBytes(file.toPath());

                dataOut.writeUTF("FILE:" + file.getName());
                dataOut.writeInt(fileData.length);
                dataOut.write(fileData);
                dataOut.flush();

                addMessage("File sent: " + file.getName(), true);
            } catch (IOException e) {
                addMessage("Error sending file", true);
            }
        }
    }

    private void readMessages() {
        try {
            while (running) {
                String command = dataIn.readUTF();
                if (command.startsWith("FILE:")) {
                    String filename = command.substring(5);
                    int length = dataIn.readInt();
                    byte[] fileData = new byte[length];
                    dataIn.readFully(fileData);

                    File received = new File(System.getProperty("user.home") + "/Downloads/" + filename);
                    received.getParentFile().mkdirs();
                    try (FileOutputStream fos = new FileOutputStream(received)) {
                        fos.write(fileData);
                    }
                    addMessage("📥 File received: " + filename + " (saved in Downloads)", false);
                } else if (command.startsWith("MSG:")) {
                    addMessage(command.substring(4), false);
                } else if (command.startsWith("LOGOUT:")) {
                    addMessage("👋 " + command.substring(7) + " left the chat.", false);
                }
            }
        } catch (IOException e) {
            addMessage(" Disconnected from server", false);
        }
    }

    private void logout() {
        running = false;
        try {
            if (dataOut != null) {
                dataOut.writeUTF("LOGOUT:" + username);
                dataOut.flush();
            }
            if (socket != null && !socket.isClosed()) socket.close();
        } catch (IOException ignored) {}

        JOptionPane.showMessageDialog(this, "You have logged out.");
        dispose();
    }

    // ---- Custom Bubble ----
    class BubbleLabel extends JLabel {
        private final Color backgroundColor;

        public BubbleLabel(String text, Color bg, Color fg) {
            super(text);
            setFont(new Font("Segoe UI", Font.PLAIN, 15));
            setOpaque(false);
            setForeground(fg);
            setBorder(new EmptyBorder(10, 14, 10, 14));
            this.backgroundColor = bg;
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            g2.setColor(backgroundColor);
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);

            g2.dispose();
            super.paintComponent(g);
        }
    }

    private void addMessage(String message, boolean isMe) {
        SwingUtilities.invokeLater(() -> {
            JPanel bubbleWrapper = new JPanel(new BorderLayout());
            bubbleWrapper.setOpaque(false);
            bubbleWrapper.setBorder(new EmptyBorder(5, 10, 5, 10));

            Color myColor = new Color(33, 150, 243);
            Color otherColor = new Color(224, 224, 224);

            BubbleLabel msgLabel;
            if (isMe) {
                msgLabel = new BubbleLabel(message, myColor, Color.white);
                bubbleWrapper.add(msgLabel, BorderLayout.EAST);
            } else {
                msgLabel = new BubbleLabel(message, otherColor, Color.black);
                bubbleWrapper.add(msgLabel, BorderLayout.WEST);
            }

            chatPanel.add(bubbleWrapper);
            chatPanel.revalidate();
            chatPanel.repaint();

            scrollPane.getVerticalScrollBar().setValue(
                    scrollPane.getVerticalScrollBar().getMaximum()
            );
        });
    }

    // ---- Main for testing ----
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ChatWindow("TestUser"));
    }
}
