package bytechat.client;

public class ClientWithLoginAndFile {
    public static void main(String[] args) {
        new LoginForm();
    }
}
