package bytechat;

import bytechat.client.ClientWithLoginAndFile;

public class Main {
    public static void main(String[] args) {
        ClientWithLoginAndFile.main(args);
    }
}
