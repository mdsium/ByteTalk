package bytechat.server;

import java.io.*;
import java.net.*;
import java.util.Set;

public class ClientHandler implements Runnable {
    private Socket socket;
    private DataOutputStream dataOut;
    private DataInputStream dataIn;
    private Set<ClientHandler> clients;

    public ClientHandler(Socket socket, Set<ClientHandler> clients) {
        this.socket = socket;
        this.clients = clients;
    }

    @Override
    public void run() {
        try {
            dataOut = new DataOutputStream(socket.getOutputStream());
            dataIn = new DataInputStream(socket.getInputStream());

            while (true) {
                String command = dataIn.readUTF();
                if (command == null) break;

                if (command.startsWith("MSG:")) {
                    // Broadcast full message (including sender)
                    broadcast(command);
                    System.out.println("💬 " + command);
                } else if (command.startsWith("FILE:")) {
                    String filename = command.substring(5);
                    int length = dataIn.readInt();
                    byte[] fileData = new byte[length];
                    dataIn.readFully(fileData);

                    System.out.println(" Received file: " + filename);
                    broadcastFile(filename, fileData);
                } else if (command.startsWith("LOGOUT:")) {
                    String user = command.substring(7);
                    System.out.println("👋 " + user + " logged out.");
                    broadcast(command); // notify others
                    break;
                }
            }
        } catch (IOException e) {
            System.out.println(" Client disconnected.");
        } finally {
            try { socket.close(); } catch (IOException ignored) {}
            clients.remove(this);
        }
    }

    private void broadcast(String message) {
        for (ClientHandler client : clients) {
            if (client != this) client.sendMessage(message);
        }
    }

    private void broadcastFile(String filename, byte[] fileData) {
        for (ClientHandler client : clients) {
            if (client != this) client.sendFile(filename, fileData);
        }
    }

    public void sendMessage(String message) {
        try {
            dataOut.writeUTF(message);
            dataOut.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void sendFile(String filename, byte[] fileData) {
        try {
            dataOut.writeUTF("FILE:" + filename);
            dataOut.writeInt(fileData.length);
            dataOut.write(fileData);
            dataOut.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
